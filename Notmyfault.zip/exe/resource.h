//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NotMyfault.rc
//
#define IDC_BUFFEROVERFLOW              1000
#define IDC_WILDPOINTER                 1001
#define IDC_DEADLOCK                    1002
#define IDC_STACKTRASH                  1003
#define IDC_HANG                        1004
#define IDC_PAGEFAULT                   1005
#define IDC_IRQL                        1006
#define IDC_LEAK                        1007
#define IDC_HANGIRP                     1008
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
